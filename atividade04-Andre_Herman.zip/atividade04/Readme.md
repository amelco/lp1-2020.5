# Explicação do funcionamento do programa

Um menu aparecerá com as opções de:
1. listar produtos do supermaercado  
2. comprar  
3. ver sacola de compras  
0. sair

Escolha a opção desejada.
Caso a opção seja a de sair, será perguntado se quer se criar um novo cliente.

## Compilação

Execute:  
```
$ make
```

## Execução
Execute:  
```
$ ./supermercado
```