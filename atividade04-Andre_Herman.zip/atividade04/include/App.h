#ifndef APP_H
#define APP_H

class App
{
    public:
    int run();

    private:
    void novo_cliente();
};

#endif // APP_H
